package com.drilldex.drillbackend.beat;

public enum LicenseType {


    MP3,
    WAV,
    PREMIUM,
    EXCLUSIVE


}
