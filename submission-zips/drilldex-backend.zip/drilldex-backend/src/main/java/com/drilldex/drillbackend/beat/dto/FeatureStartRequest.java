// src/main/java/com/drilldex/drillbackend/beat/dto/FeatureStartRequest.java
package com.drilldex.drillbackend.beat.dto;

public record FeatureStartRequest(String tier, int days) {}