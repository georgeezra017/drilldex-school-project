package com.drilldex.drillbackend.admin.dto;

public record RejectRequest(String reason) {}
