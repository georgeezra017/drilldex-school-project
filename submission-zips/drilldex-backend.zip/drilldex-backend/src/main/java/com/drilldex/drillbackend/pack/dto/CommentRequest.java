package com.drilldex.drillbackend.pack.dto;

public record CommentRequest(String text) { }