package com.drilldex.drillbackend.user.dto;

public class BeatUploadRequest {
}
