package com.drilldex.drillbackend.user;

// user/Role.java
public enum Role {
    USER,
    ARTIST,
    ADMIN
}