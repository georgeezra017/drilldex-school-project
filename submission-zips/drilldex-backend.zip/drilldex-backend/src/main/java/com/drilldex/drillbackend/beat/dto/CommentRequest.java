// src/main/java/com/drilldex/drillbackend/beat/dto/CommentRequest.java
package com.drilldex.drillbackend.beat.dto;

public record CommentRequest(String text) {}