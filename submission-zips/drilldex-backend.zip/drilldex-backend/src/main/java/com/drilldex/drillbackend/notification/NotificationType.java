package com.drilldex.drillbackend.notification;

public enum NotificationType {
    CHAT,
    PURCHASE,
    PROMOTION,
    FOLLOW,
    SYSTEM
}