// src/main/java/com/drilldex/drillbackend/kit/dto/CommentRequest.java
package com.drilldex.drillbackend.kit.dto;

public record CommentRequest(String text) {}