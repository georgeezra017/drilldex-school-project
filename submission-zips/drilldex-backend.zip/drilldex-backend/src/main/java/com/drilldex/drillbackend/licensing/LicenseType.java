//package com.drilldex.drillbackend.licensing;
//
//public enum LicenseType {
//    FREE,
//    BASIC,
//    PREMIUM,
//    UNLIMITED,
//    EXCLUSIVE
//}