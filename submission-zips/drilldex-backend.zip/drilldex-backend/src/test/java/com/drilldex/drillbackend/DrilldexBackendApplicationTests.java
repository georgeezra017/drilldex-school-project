package com.drilldex.drillbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrilldexBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
